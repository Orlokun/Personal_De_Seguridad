namespace GamePlayManagement.Players_NPC.Animations.Interfaces
{
    public interface IHumanoidFightAnimatedAgent : IBaseAnimatedAgent
    {
        //TODO: Add Get: Current HitState
        //TODO: Add Get: C
        //TODO: Add Get
        //TODO: Add Get
        //TODO: Add Get
    }
}