﻿using GamePlayManagement.Players_NPC.NPC_Management.Customer_Management.StateMachines.MovementStates;

namespace GamePlayManagement.Players_NPC.NPC_Management.Customer_Management.StateMachines.AttitudeStates
{
    public class AccessingBuildingState : IAttitudeState, IAccessingBuildingState
    {
        private BaseCharacterInScene character;

        public AccessingBuildingState(BaseCharacterInScene character)
        {
            this.character = character;
        }

        public void Enter()
        {
            character.ChangeMovementState<WalkingState>();
            SetMovementDestination(_entranceData.EntrancePosition);
        }

        public void Exit() { }

        public void Update() { }
        
    }

    public interface IAccessingBuildingState
    {
        
    }
}