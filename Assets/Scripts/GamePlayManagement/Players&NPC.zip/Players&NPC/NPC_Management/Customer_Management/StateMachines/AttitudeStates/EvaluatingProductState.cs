﻿using System;
using System.Collections;
using System.Threading.Tasks;
using GamePlayManagement.Players_NPC.NPC_Management.Customer_Management.StateMachines.MovementStates;
using UnityEngine;
using Random = UnityEngine.Random;

namespace GamePlayManagement.Players_NPC.NPC_Management.Customer_Management.StateMachines.AttitudeStates
{
    public class EvaluatingProductState : IAttitudeState
    {
        //Eventually change into restricted interface
        private BaseCustomer _customer;

        public EvaluatingProductState(BaseCustomer customer)
        {
            _customer = customer;
        }

        public void Enter()
        {
            _customer.SetCharacterMovementStatus(BaseCharacterMovementStatus.Idle);
            _customer.SetCharacterAttitudeStatus(BaseCharacterAttitudeStatus.EvaluatingProduct);
            var wouldStealProduct = EvaluateProductStealingChances();
            StartProductExamination(wouldStealProduct);
        }

        public void Exit() { }

        public void Update() { }

        private bool EvaluateProductStealingChances()
        {
            var hasStealAbility = _customer.TempStoreProductOfInterest.Item2.HideChances <= _customer.CustomerTypeData.StealAbility ? 1 : 0;
            var isTempting = _customer.TempStoreProductOfInterest.Item2.Tempting >= _customer.CustomerTypeData.Corruptibility ? 1 : 0;
            var isDetermined = _customer.TempStoreProductOfInterest.Item2.Punishment <= _customer.CustomerTypeData.Fearful ? 1 : 0;

            return hasStealAbility + isTempting + isDetermined >= 2;
        }

        private async void StartProductExamination(bool wouldStealProduct)
        {
            Random.InitState(DateTime.Now.Millisecond);
            await Task.Delay(Random.Range(1500, 2000));
            _customer.GrabObjectConstraint.data.target = _customer.TempTargetOfInterest.transform;
            _customer.StartCoroutine(SetGrabObjectConstraint(0, 1, 1));
            await Task.Delay(1000);
            InstantiateProductInHand();
            StartInspectObjectAnim();
            await Task.Delay(1000);
            if (!wouldStealProduct)
            {
                AddProductAndKeepShopping();
            }
            else
            {
                StartStealingProductAttempt();
            }
        }

        private void InstantiateProductInHand()
        {
            var path = _customer.ProductPrefabPath + _customer.TempStoreProductOfInterest.Item2.PrefabName;
            _customer.TempProductCopy = (GameObject)Instantiate(Resources.Load(path), _customer.RightHand, false);
            _customer.ProductInHand = true;
            _customer.TempProductCopy.transform.localScale *= .4f;
            _customer.TempProductCopy.transform.localPosition = new Vector3(0, 0, 0);
            _customer.TempTargetOfInterest = _customer.TempProductCopy.transform;
        }

        private void StartInspectObjectAnim()
        {
            _customer.StartCoroutine(SetGrabObjectConstraint(1, 0, 1));
            _customer.StartCoroutine(SetLookObjectWeight(0, 1, 1));
            _customer.StartCoroutine(UpdateInspectObjectRigWeight(0, 1, 1));
        }

        private IEnumerator SetLookObjectWeight(float start, float end, float time)
        {
            float elapsedTime = 0;
            while (elapsedTime < time)
            {
                _customer.HeadAimConstraint.weight = Mathf.Lerp(start, end, (elapsedTime / time));
                elapsedTime += Time.deltaTime;
                yield return null;
            }
        }

        private IEnumerator UpdateInspectObjectRigWeight(float start, float end, float time)
        {
            float elapsedTime = 0;
            while (elapsedTime < time)
            {
                _customer.InspectObjectConstraint.weight = Mathf.Lerp(start, end, (elapsedTime / time));
                elapsedTime += Time.deltaTime;
                yield return null;
            }
        }

        private IEnumerator SetGrabObjectConstraint(float start, float end, float time)
        {
            float elapsedTime = 0;
            while (elapsedTime < time)
            {
                _customer.GrabObjectConstraint.weight = Mathf.Lerp(start, end, (elapsedTime / time));
                elapsedTime += Time.deltaTime;
                yield return null;
            }
        }

        private async void AddProductAndKeepShopping()
        {
            Debug.Log("[AddProductAndKeepShopping] WOULD NOT STEAL PRODUCT");
            await Task.Delay(Random.Range(4500, 10000));
            _customer.StartCoroutine(UpdateInspectObjectRigWeight(1, 0, 1));
            _customer.CustomerVisitData.PurchaseProduct(Guid.NewGuid(), _customer.TempStoreProductOfInterest.Item2);
            ClearProductInterest();
            _customer.PoisPurchaseStatus[_customer.CurrentPoiId] = true;
            _customer.SetCharacterMovementStatus(BaseCharacterMovementStatus.Walking);
            _customer.ChangeCharacterAttitudeState<BaseCharacterAttitudeStatus.Shopping>();
            _customer.ReleaseCurrentPoI();
            _customer.GoToNextProduct();
        }

        private async void StartStealingProductAttempt()
        {
            Debug.Log($"[StartProductExamination] {_customer.gameObject.name} WOULD STEAL PRODUCT. Start Process");
            await Task.Delay(Random.Range(1000, 1500));

            _customer.StartCoroutine(SetLookObjectWeight(1, 0, 1.5f));
            _customer.BaseAnimator.ChangeAnimationState(_customer.SearchAround);
            await Task.Delay(8000);
            _customer.StartCoroutine(UpdateInspectObjectRigWeight(1, 0, 1));
            _customer.CustomerVisitData.StealProduct(Guid.NewGuid(), _customer.TempStoreProductOfInterest.Item2);
            ClearProductInterest();
            _customer.PoisPurchaseStatus[_customer.CurrentPoiId] = true;
            _customer.SetCharacterMovementStatus(BaseCharacterMovementStatus.Walking);
            _customer.ChangeCharacterAttitudeState<BaseCharacterAttitudeStatus.Shopping>();
            _customer.ReleaseCurrentPoI();
            _customer.GoToNextProduct();
        }

        private void ClearProductInterest()
        {
            Destroy(_customer.TempProductCopy);
            _customer.TempTargetOfInterest = null;
            _customer.ProductInHand = false;
            _customer.TempProductCopy = null;
        }
    }
}