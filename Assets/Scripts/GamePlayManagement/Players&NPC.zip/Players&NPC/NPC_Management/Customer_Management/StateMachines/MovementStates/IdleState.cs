﻿namespace GamePlayManagement.Players_NPC.NPC_Management.Customer_Management.StateMachines.MovementStates
{
    public class IdleState : IIdleState
    {
        private BaseCharacterInScene character;

        public IdleState(BaseCharacterInScene character)
        {
            this.character = character;
        }

        public void Enter()
        {
            character.SetCharacterMovementStatus(BaseCharacterMovementStatus.Idle);
        }

        public void Exit() { }

        public void Update() { }
    }

    public interface IIdleState : IMovementState
    {
        
    }
}