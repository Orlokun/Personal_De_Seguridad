﻿using System;

namespace GamePlayManagement.Players_NPC.NPC_Management.Customer_Management.StateMachines.AttitudeStates
{
    [Flags]
    public enum BaseCharacterAttitudeStatus
    {
        Idle = 1,
        Fighting = 2,
        Stealing = 4,
        Shopping = 8,
        Paying = 16,
        Leaving = 32,           //Remove
        Entering = 64,          //Remove
        EvaluatingProduct = 128,
        WonderingAround = 256,
        Screaming = 512,
        Talking = 1024,
        ScareCrouched = 2048,
        ScaredRunningAway = 4096,
    }
}