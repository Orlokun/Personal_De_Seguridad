﻿namespace GamePlayManagement.Players_NPC.NPC_Management.Customer_Management.StateMachines.MovementStates
{
    public class RunningState : IMovementState
    {
        private BaseCharacterInScene character;

        public RunningState(BaseCharacterInScene character)
        {
            this.character = character;
        }

        public void Enter()
        {
            character.SetCharacterMovementStatus(BaseCharacterMovementStatus.Running);
        }

        public void Exit() { }

        public void Update() { }
    }
}