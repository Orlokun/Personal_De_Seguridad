﻿namespace GamePlayManagement.Players_NPC.NPC_Management.Customer_Management.StateMachines.MovementStates
{
    public class WalkingState : IMovementState
    {
        private BaseCharacterInScene character;

        public WalkingState(BaseCharacterInScene character)
        {
            this.character = character;
        }

        public void Enter()
        {
            character.SetCharacterMovementStatus(BaseCharacterMovementStatus.Walking);
        }

        public void Exit() { }

        public void Update()
        {
            character.EvaluateWalkingDestination();
        }
    }
}