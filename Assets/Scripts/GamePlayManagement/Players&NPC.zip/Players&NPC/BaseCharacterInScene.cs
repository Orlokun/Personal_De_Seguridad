using System;
using DataUnits.ItemScriptableObjects;
using GameDirection.GeneralLevelManager.ShopPositions;
using GamePlayManagement.ItemManagement.Guards;
using GamePlayManagement.Players_NPC.Animations;
using GamePlayManagement.Players_NPC.Animations.Interfaces;
using GamePlayManagement.Players_NPC.NPC_Management.Customer_Management;
using GamePlayManagement.Players_NPC.NPC_Management.Customer_Management.StateMachines;
using GamePlayManagement.Players_NPC.NPC_Management.Customer_Management.StateMachines.AttitudeStates;
using GamePlayManagement.Players_NPC.NPC_Management.Customer_Management.StateMachines.MovementStates;
using UnityEngine;
using UnityEngine.AI;

namespace GamePlayManagement.Players_NPC
{
    /// <summary>
    /// THIS CLASS MUST BE TURNED INTO A PROPER STATE MACHINE
    /// </summary>
    [RequireComponent(typeof(NavMeshAgent))]
    [RequireComponent(typeof(Animator))]
    [RequireComponent(typeof(BaseAnimatedAgent))]
    public abstract class BaseCharacterInScene : MonoBehaviour, IBaseCharacterInScene
    {
        //Many of these should eventually be managed through code: speeds, etc.
        #region Constants
        protected const float BaseWalkSpeed = 3.5f;
        protected const float BaseRunSpeed = 15f;
        protected const int BaseAwakeTime = 5000;
        
        protected const string Idle = "Idle";
        protected const string Walk = "Walk";
        protected const string Run = "Run";        
        protected const string SearchAround = "SearchAround";
        #endregion

        #region Protected Data, components and references
        protected Guid MCharacterId;
        protected IItemTypeStats MyStats;
        protected BaseCharacterMovementStatus MCharacterMovementStatus = BaseCharacterMovementStatus.Idle;
        protected IBaseAnimatedAgent BaseAnimator;
        protected NavMeshAgent MyNavMeshAgent;
        protected Vector3 MInitialPosition;
        protected IShopPositionsManager PositionsManager;
        #endregion

        #region StateMachine
        protected StateMachine<IMovementState> _mMovementStateMachine;
        protected StateMachine<IAttitudeState> _mAttitudeStateMachine;
        #endregion

        public Guid CharacterId => MCharacterId;
        public NavMeshAgent GetNavMeshAgent => MyNavMeshAgent;
        public void ToggleNavMesh(bool isActive)
        {
            //ObstacleComponent.enabled = !isActive;
            if (MyNavMeshAgent.enabled)
            {
                MyNavMeshAgent.isStopped = !isActive;
                MyNavMeshAgent.enabled = isActive;
            }
            else
            {
                MyNavMeshAgent.enabled = isActive;
                MyNavMeshAgent.isStopped = !isActive;
            }
        }

        public void ChangeMovementState<T>() where T : IMovementState
        {
            _mMovementStateMachine.ChangeState<T>();
        }
        public void ChangeAttitudeState<T>() where T : IAttitudeState
        {
            _mAttitudeStateMachine.ChangeState<T>();
        }
        //protected NavMeshObstacle ObstacleComponent;

        protected float MRotationSpeed = 12;
        [SerializeField] protected Transform headTransform;     

        #region Events
        private delegate void ReachDestination();
        private event ReachDestination WalkingDestinationReached;

        #endregion
        protected virtual void Awake()
        {
            CheckId();
            InitiateStateMachines();
            PositionsManager = FindFirstObjectByType<ShopPositionsManager>();    
            BaseAnimator = GetComponent<BaseAnimatedAgent>();
            MyNavMeshAgent = GetComponent<NavMeshAgent>();
            BaseAnimator.Initialize(GetComponent<Animator>());
            //ObstacleComponent = GetComponent<NavMeshObstacle>();
            //ObstacleComponent.enabled = false;
            WalkingDestinationReached += ReachWalkingDestination;
        }

        private void CheckId()
        {
            if (MCharacterId == Guid.Empty)
            {
                MCharacterId = Guid.NewGuid();
            }
        }

        private void InitiateStateMachines()
        {
            _mMovementStateMachine = new StateMachine<IMovementState>();
            _mMovementStateMachine.AddState(new IdleState(this));
            _mMovementStateMachine.AddState(new WalkingState(this));
            _mMovementStateMachine.AddState(new RunningState(this));
            
            _mAttitudeStateMachine = new StateMachine<IAttitudeState>();
            _mAttitudeStateMachine.AddState(new IdleAttitudeState(this));
            _mAttitudeStateMachine.AddState(new AccessingBuildingState(this));
            _mAttitudeStateMachine.AddState(new TalkingState(this));
            _mAttitudeStateMachine.AddState(new ShoppingState(this));
            _mAttitudeStateMachine.AddState(new StealingState(this));
            _mAttitudeStateMachine.AddState(new EvaluatingProductState(this));
            _mAttitudeStateMachine.AddState(new ScreamingState(this));
            _mAttitudeStateMachine.AddState(new FightingState(this));
            _mAttitudeStateMachine.AddState(new PayingState(this));
            _mAttitudeStateMachine.AddState(new ScaredCrouchState(this));
            _mAttitudeStateMachine.AddState(new ScaredRunningState(this));
        }
        
        protected virtual void Start()
        {
        }
        protected virtual void RotateTowardsYOnly(Transform rotatingObject, Transform facingTowards)
        {
            Vector3 targetDirection = facingTowards.position - rotatingObject.position;
            targetDirection.y = 0; // Ignore height difference
            Quaternion targetRotation = Quaternion.LookRotation(targetDirection);
            // Smoothly rotate towards the target
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, MRotationSpeed * Time.deltaTime);
        }

        protected virtual void ReachWalkingDestination()
        {
            
        }
        
        protected void StartWalking()
        {
            SetCharacterMovementStatus(BaseCharacterMovementStatus.Walking);
            BaseAnimator.ChangeAnimationState(Walk);
        }
        protected void NavAgentUpdateStatusStats(BaseCharacterMovementStatus currentStatus)
        {
            MyNavMeshAgent.speed = GetStatusSpeed(currentStatus);
        }
        protected virtual float GetStatusSpeed(BaseCharacterMovementStatus currentStatus)
        {
            return 1;
        }

        protected void SetMovementDestination(Vector3 targetPosition)
        {
            MyNavMeshAgent.enabled = true;
            MyNavMeshAgent.isStopped = false;
            MyNavMeshAgent.SetDestination(targetPosition);
        }

        public virtual void ChangeCharacterAttitudeState(BaseCharacterAttitudeStatus characterAttitudeStatus)
        {
            
        }
        public virtual void SetCharacterAttitudeStatus(GuardSpecialAttitudeStatus guardAttitudeStatus)
        {
            
        }

        public BaseCharacterMovementStatus CharacterMovementStatus { get; }

        public void SetCharacterMovementStatus(BaseCharacterMovementStatus newMovementStatus)
        {
            MCharacterMovementStatus = 0;
            MCharacterMovementStatus |= newMovementStatus;
            //set
            switch (newMovementStatus)
            {
                case  BaseCharacterMovementStatus.Walking:
                    NavAgentUpdateStatusStats(BaseCharacterMovementStatus.Walking);
                    BaseAnimator.ChangeAnimationState(Walk);
                    break;
                case  BaseCharacterMovementStatus.Idle:
                    //ToggleNavMesh(false);
                    BaseAnimator.ChangeAnimationState(Idle);
                    break;
                case  BaseCharacterMovementStatus.Running:
                    NavAgentUpdateStatusStats(BaseCharacterMovementStatus.Running);
                    //ToggleNavMesh(true);
                    BaseAnimator.ChangeAnimationState(Run);
                    break;
            }
        }

        protected virtual void ProcessInViewTargets()
        {
            //Must be implemented by inheritor if used     
        }
        public void EvaluateWalkingDestination()
        {
            if (MyNavMeshAgent.destination.Equals(default(Vector3)))
            {
                Debug.LogWarning("Destination to walk to must be already set");
                return;
            }
            ConfirmAttitudeStatusData();
            if (MyNavMeshAgent.remainingDistance < 1f && !MyNavMeshAgent.isStopped)
            {
                MyNavMeshAgent.isStopped = true;
                OnWalkingDestinationReached();
            }
        }

        protected virtual void ConfirmAttitudeStatusData()
        {
            
        }

        protected virtual void OnWalkingDestinationReached()
        {
            WalkingDestinationReached?.Invoke();
        }
    }
}